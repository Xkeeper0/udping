function love.conf(t)

	t.version	= "11.2"
	t.window.title	= "UDPing Network Monitor"
	t.window.width	= 1280
	t.window.height	= 720
end
