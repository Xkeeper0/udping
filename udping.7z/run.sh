#!/bin/sh
#bin/love.exe .
'/c/Program Files/LOVE/love.exe' .
